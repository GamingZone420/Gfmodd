# Girlfriend Mod (Fabric 1.21.3)

## Build
1. JDK 21 install karo.
2. Is folder mein terminal kholo:
   - Windows: `gradlew.bat build`
   - Mac/Linux: `./gradlew build`
3. Jar milega: `build/libs/girlfriendmod-1.0.0.jar` (`-sources.jar` wala nahi).

## Chalane ke liye mods folder mein ye dono daalo
- `girlfriendmod-1.0.0.jar`
- Fabric API 0.114.1+1.21.3

## In-game commands
- `/gf spawn`, `/gf remove`
- `/gf link <groq-key>`, `/gf unlink`, `/gf current`
- `/gf model <naam>` (agar default model band ho jaye)

Skin: `src/main/resources/assets/girlfriendmod/textures/entity/girlfriend.png` (slim/Alex).
Naam badalna ho toh `GirlfriendEntity.GF_NAME`.

GitHub pe push karoge toh `.github/workflows/build.yml` khud jar bana dega (Actions > Artifacts).
