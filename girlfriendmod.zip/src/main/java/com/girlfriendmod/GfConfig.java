package com.girlfriendmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class GfConfig {
    public static String apiKey = "";
    // Agar ye model band ho jaye toh in-game: /gf model <naya-model>
    public static String model = "llama-3.3-70b-versatile";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("girlfriendmod.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
                if (o.has("apiKey")) apiKey = o.get("apiKey").getAsString();
                if (o.has("model")) model = o.get("model").getAsString();
            } else {
                save();
            }
        } catch (Exception e) {
            System.err.println("[girlfriendmod] config load failed: " + e.getMessage());
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("apiKey", apiKey);
            o.addProperty("model", model);
            Files.writeString(file(), GSON.toJson(o));
        } catch (Exception e) {
            System.err.println("[girlfriendmod] config save failed: " + e.getMessage());
        }
    }

    /** Key kabhi poori nahi dikhate, sirf shuru aur aakhir ke kuch characters. */
    public static String masked() {
        if (apiKey == null || apiKey.isBlank()) return "(koi API linked nahi hai)";
        if (apiKey.length() <= 10) return "****";
        return apiKey.substring(0, 4) + "..." + apiKey.substring(apiKey.length() - 4);
    }
}
