package com.girlfriendmod;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class GroqClient {
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();
    private static final URI URL = URI.create("https://api.groq.com/openai/v1/chat/completions");

    /** Alag thread pe chalta hai, game lag nahi karta. Error pe RuntimeException (friendly message) deta hai. */
    public static CompletableFuture<String> chat(String system, List<JsonObject> history) {
        final String key = GfConfig.apiKey;
        final String model = GfConfig.model;
        return CompletableFuture.supplyAsync(() -> {
            try {
                JsonObject body = new JsonObject();
                body.addProperty("model", model);
                body.addProperty("temperature", 0.9);
                body.addProperty("max_tokens", 200);

                JsonArray msgs = new JsonArray();
                JsonObject sys = new JsonObject();
                sys.addProperty("role", "system");
                sys.addProperty("content", system);
                msgs.add(sys);
                for (JsonObject m : history) msgs.add(m);
                body.add("messages", msgs);

                HttpRequest req = HttpRequest.newBuilder(URL)
                        .timeout(Duration.ofSeconds(30))
                        .header("Content-Type", "application/json")
                        .header("User-Agent", "girlfriendmod/1.0 (Minecraft Fabric mod)")
                        .header("Authorization", "Bearer " + key)
                        .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                        .build();

                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                int code = res.statusCode();
                if (code == 401) throw new RuntimeException("API key galat ya expire hai. /gf link <key> se dobara daalo.");
                if (code == 404 || code == 400) throw new RuntimeException("Model shayad galat/band hai (" + model + "). /gf model <naam> try karo.");
                if (code == 403) throw new RuntimeException("Groq ne request block kar di (403). Key check karo ya thodi der baad try karo.");
                if (code == 429) throw new RuntimeException("Rate limit hit ho gayi, thodi der baad try karo.");
                if (code / 100 != 2) throw new RuntimeException("Groq error " + code);

                JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
                return o.getAsJsonArray("choices").get(0).getAsJsonObject()
                        .getAsJsonObject("message").get("content").getAsString().trim();
            } catch (RuntimeException e) {
                throw e;
            } catch (Exception e) {
                throw new RuntimeException("Groq se connect nahi ho paya (internet check karo).");
            }
        });
    }
}
