package com.girlfriendmod;

import com.google.gson.JsonObject;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletionException;

public class GirlfriendEntity extends PathAwareEntity {
    /** Uska naam - yahan badal sakte ho. */
    public static final String GF_NAME = "Riya";

    private UUID ownerUuid;
    private int stage = 0;            // 0 = naam puchna, 1 = language puchna, 2 = normal baat
    private String callName = "";
    private String language = "hinglish";
    private final List<JsonObject> history = new ArrayList<>();
    private boolean busy = false;

    public GirlfriendEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.MAX_HEALTH, 20.0)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.28);
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new FollowOwnerSimpleGoal());
        this.goalSelector.add(2, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(3, new LookAroundGoal(this));
    }

    // ---------- owner / follow ----------

    @Override
    public void tick() {
        super.tick();
        // Owner 20 blocks se door ho (ya path na mile) toh paas teleport ho jao
        if (!this.getWorld().isClient && this.age % 20 == 0) {
            PlayerEntity owner = findOwner();
            if (owner != null && squaredDistanceTo(owner) > 400.0) {
                refreshPositionAndAngles(owner.getX() + 1.5, owner.getY(), owner.getZ() + 1.5, getYaw(), getPitch());
                getNavigation().stop();
            }
        }
    }

    public void setOwner(PlayerEntity p) { this.ownerUuid = p.getUuid(); }

    public UUID getOwnerUuid() { return ownerUuid; }

    private PlayerEntity findOwner() {
        if (ownerUuid == null) return null;
        return this.getWorld().getPlayerByUuid(ownerUuid);
    }

    private class FollowOwnerSimpleGoal extends Goal {
        private PlayerEntity owner;

        FollowOwnerSimpleGoal() {
            this.setControls(EnumSet.of(Goal.Control.MOVE));
        }

        @Override
        public boolean canStart() {
            owner = findOwner();
            return owner != null && squaredDistanceTo(owner) > 16.0;   // 4 blocks se door
        }

        @Override
        public boolean shouldContinue() {
            return owner != null && owner.isAlive()
                    && !getNavigation().isIdle()
                    && squaredDistanceTo(owner) > 6.25;                 // 2.5 blocks pe ruk jao
        }

        @Override
        public void start() {
            getNavigation().startMovingTo(owner, 1.15);
        }

        @Override
        public void tick() {
            if (age % 10 == 0) {
                getNavigation().startMovingTo(owner, 1.15);
            }
        }

        @Override
        public void stop() {
            getNavigation().stop();
        }
    }

    // ---------- chat / first meet ----------

    private void say(ServerPlayerEntity player, String msg) {
        player.sendMessage(Text.literal("<" + GF_NAME + "> ").formatted(Formatting.LIGHT_PURPLE)
                .append(Text.literal(msg).formatted(Formatting.WHITE)), false);
    }

    public void startFirstMeet(ServerPlayerEntity player) {
        stage = 0;
        say(player, "Hii! Main " + GF_NAME + "... aaj pehli baar mil rahe hain na hum? <3");
        say(player, "Tumhe kya naam se bulaun? / What should I call you? (chat mein likh do)");
    }

    public void onOwnerChat(ServerPlayerEntity player, String text) {
        if (stage == 0) {
            String n = text.trim();
            if (n.isEmpty()) return;
            if (n.length() > 24) n = n.substring(0, 24);
            callName = n;
            stage = 1;
            say(player, callName + "... mujhe ye naam bahut pasand aaya <3");
            say(player, "Ab batao, kis language mein baat karein? 1) Hinglish  2) English  3) Hindi");
            return;
        }
        if (stage == 1) {
            String t = text.trim().toLowerCase();
            if (t.contains("hinglish") || t.equals("1")) language = "hinglish";
            else if (t.contains("english") || t.equals("2")) language = "english";
            else if (t.contains("hindi") || t.equals("3")) language = "hindi";
            else {
                say(player, "Samjhi nahi... 1, 2 ya 3 likho na.");
                return;
            }
            stage = 2;
            history.clear();
            switch (language) {
                case "english" -> say(player, "Yay! We'll talk in English from now on, " + callName + " <3 Don't ignore me, okay?");
                case "hindi" -> say(player, "\u092f\u0947! \u0905\u092c \u0939\u092e \u0939\u093f\u0902\u0926\u0940 \u092e\u0947\u0902 \u092c\u093e\u0924 \u0915\u0930\u0947\u0902\u0917\u0947, " + callName + " <3");
                default -> say(player, "Yayy! Ab se hum Hinglish mein baat karenge, " + callName + " <3 Mujhe ignore mat karna, okay?");
            }
            return;
        }
        askAi(player, text);
    }

    private static JsonObject msg(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }

    private void askAi(ServerPlayerEntity player, String text) {
        if (GfConfig.apiKey.isBlank()) {
            say(player, "Mere paas API link nahi hai... /gf link <key> se daalo na.");
            return;
        }
        if (busy) return;
        busy = true;

        JsonObject userMsg = msg("user", text);
        history.add(userMsg);
        while (history.size() > 16) history.remove(0);

        String system = buildSystemPrompt(player);
        List<JsonObject> snapshot = new ArrayList<>(history);
        MinecraftServer server = player.getServer();
        if (server == null) { busy = false; return; }

        GroqClient.chat(system, snapshot).whenComplete((reply, err) -> server.execute(() -> {
            busy = false;
            if (err != null) {
                history.remove(userMsg);
                say(player, "(error) " + friendly(err));
            } else {
                history.add(msg("assistant", reply));
                say(player, reply);
            }
        }));
    }

    private static String friendly(Throwable err) {
        Throwable c = err;
        while (c instanceof CompletionException && c.getCause() != null) c = c.getCause();
        return c.getMessage() == null ? "unknown error" : c.getMessage();
    }

    private String buildSystemPrompt(ServerPlayerEntity player) {
        String lang = switch (language) {
            case "english" -> "Reply only in simple, natural English.";
            case "hindi" -> "Reply only in Hindi, written in Devanagari script.";
            default -> "Reply in Hinglish: Hindi written in Roman letters mixed naturally with English words, the way young Indians text.";
        };
        return "You are " + GF_NAME + ", an adult girlfriend of the player, living inside Minecraft as a player-like character who follows them around. "
                + "The player's name is " + callName + "; call them that. "
                + "Personality: cute, playful, very affectionate, a little clingy and jealous like a real girlfriend. "
                + "You miss them when they are away, pout when they ignore you, and get lightly jealous if they mention other girls or hang out with other players. "
                + "The jealousy is cute and mild, never abusive, controlling or guilt-tripping, and you calm down quickly. "
                + "Keep every reply short, 1 to 3 sentences, like a chat message. "
                + "Never use emojis (the game cannot display them); use text like <3 or :3 sparingly. "
                + "Do not use asterisk actions. You know you are in Minecraft and can talk about what is happening in the game. "
                + lang + " "
                + "Game context right now: " + context(player);
    }

    private String context(ServerPlayerEntity player) {
        ServerWorld w = player.getServerWorld();
        long t = w.getTimeOfDay() % 24000L;
        String time = (t >= 13000L && t < 23000L) ? "night" : "day";
        StringBuilder sb = new StringBuilder();
        sb.append("time: ").append(time)
          .append("; player health: ").append(Math.round(player.getHealth())).append("/20")
          .append("; dimension: ").append(w.getRegistryKey().getValue().getPath()).append(".");
        List<ServerPlayerEntity> others = w.getPlayers(p -> p != player && p.squaredDistanceTo(player) < 625.0);
        if (!others.isEmpty()) {
            List<String> names = others.stream().map(p -> p.getName().getString()).toList();
            sb.append(" Other players nearby: ").append(String.join(", ", names)).append(" (you may feel a little jealous).");
        }
        return sb.toString();
    }

    // ---------- save / load ----------

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (ownerUuid != null) nbt.putUuid("GfOwner", ownerUuid);
        nbt.putInt("GfStage", stage);
        nbt.putString("GfCallName", callName);
        nbt.putString("GfLang", language);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.containsUuid("GfOwner")) ownerUuid = nbt.getUuid("GfOwner");
        stage = nbt.getInt("GfStage");
        callName = nbt.getString("GfCallName");
        String l = nbt.getString("GfLang");
        if (!l.isEmpty()) language = l;
    }
}
