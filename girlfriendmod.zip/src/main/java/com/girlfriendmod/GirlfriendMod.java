package com.girlfriendmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public class GirlfriendMod implements ModInitializer {
    public static final String MOD_ID = "girlfriendmod";

    public static final RegistryKey<EntityType<?>> GF_KEY =
            RegistryKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(MOD_ID, "girlfriend"));

    public static final EntityType<GirlfriendEntity> GIRLFRIEND = Registry.register(
            Registries.ENTITY_TYPE, GF_KEY,
            EntityType.Builder.create(GirlfriendEntity::new, SpawnGroup.CREATURE)
                    .dimensions(0.6f, 1.8f)
                    .build(GF_KEY));

    @Override
    public void onInitialize() {
        GfConfig.load();
        FabricDefaultAttributeRegistry.register(GIRLFRIEND, GirlfriendEntity.createAttributes());

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                GfCommands.register(dispatcher));

        // Player ka chat message girlfriend tak pahunchao
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String text = message.getSignedContent();
            for (GirlfriendEntity gf : sender.getServerWorld().getEntitiesByType(GIRLFRIEND,
                    g -> g.isAlive() && sender.getUuid().equals(g.getOwnerUuid()))) {
                gf.onOwnerChat(sender, text);
                break;
            }
        });
    }
}
