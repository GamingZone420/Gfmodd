package com.girlfriendmod;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

import java.util.List;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class GfCommands {

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("gf")
                .then(literal("spawn").executes(ctx -> spawn(ctx.getSource())))
                .then(literal("remove").executes(ctx -> remove(ctx.getSource())))
                .then(literal("link").then(argument("key", StringArgumentType.string()).executes(ctx -> {
                    GfConfig.apiKey = StringArgumentType.getString(ctx, "key").trim();
                    GfConfig.save();
                    reply(ctx.getSource(), "API link ho gayi: " + GfConfig.masked());
                    return 1;
                })))
                .then(literal("unlink").executes(ctx -> {
                    GfConfig.apiKey = "";
                    GfConfig.save();
                    reply(ctx.getSource(), "API unlink ho gayi.");
                    return 1;
                }))
                .then(literal("current").executes(ctx -> {
                    reply(ctx.getSource(), "Current API: " + GfConfig.masked() + " | Model: " + GfConfig.model);
                    return 1;
                }))
                .then(literal("model").then(argument("name", StringArgumentType.string()).executes(ctx -> {
                    GfConfig.model = StringArgumentType.getString(ctx, "name").trim();
                    GfConfig.save();
                    reply(ctx.getSource(), "Model set: " + GfConfig.model);
                    return 1;
                }))));
    }

    private static void reply(ServerCommandSource src, String msg) {
        src.sendFeedback(() -> Text.literal(msg), false);
    }

    private static List<? extends GirlfriendEntity> owned(ServerPlayerEntity p) {
        return p.getServerWorld().getEntitiesByType(GirlfriendMod.GIRLFRIEND,
                g -> g.isAlive() && p.getUuid().equals(g.getOwnerUuid()));
    }

    private static int spawn(ServerCommandSource src) {
        ServerPlayerEntity p = src.getPlayer();
        if (p == null) {
            reply(src, "Ye command sirf player chala sakta hai.");
            return 0;
        }
        if (!owned(p).isEmpty()) {
            reply(src, "Wo pehle se tumhare paas hai. (/gf remove se hata sakte ho)");
            return 0;
        }
        ServerWorld w = p.getServerWorld();
        GirlfriendEntity gf = GirlfriendMod.GIRLFRIEND.create(w, SpawnReason.COMMAND);
        if (gf == null) return 0;
        gf.refreshPositionAndAngles(p.getX() + 1.5, p.getY(), p.getZ() + 1.5, p.getYaw() + 180f, 0f);
        gf.setOwner(p);
        gf.setCustomName(Text.literal(GirlfriendEntity.GF_NAME));
        gf.setCustomNameVisible(true);
        w.spawnEntity(gf);
        gf.startFirstMeet(p);
        return 1;
    }

    private static int remove(ServerCommandSource src) {
        ServerPlayerEntity p = src.getPlayer();
        if (p == null) return 0;
        List<? extends GirlfriendEntity> list = owned(p);
        for (GirlfriendEntity g : list) g.discard();
        reply(src, list.isEmpty() ? "Koi girlfriend nahi mili." : "Hata di. /gf spawn se naya start karo.");
        return 1;
    }
}
