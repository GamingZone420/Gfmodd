package com.girlfriendmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class GirlfriendClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(GirlfriendMod.GIRLFRIEND, GirlfriendRenderer::new);
    }
}
